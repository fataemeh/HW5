//فاطمه رضوانی زاده
//40223034
#include<stdio.h>
int main()
{
    int n, i , j , count ;
    printf("enter a number");
    scanf("%d" , &n);
    if(n<=0)
    printf("try again");
    else{
        printf("enter an expression of long %d" , n);
        char a[n];
        scanf("%s" , a);

        for(i=0;i<n;i++){
            if(a[i]==a[i+1])   {
            count=0;
            count++;
            j=i;
            i=-1;
            for(j;j<n-1;j++)
            a[j]=a[j+2];
        
            if(count!=0)
            printf("%s\n" , a);
                                }
                        }    
        }
}